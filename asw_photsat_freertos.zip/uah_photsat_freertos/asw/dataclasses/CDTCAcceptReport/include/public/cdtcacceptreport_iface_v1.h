/*
 * cdtcdescriptor_iface_v1.h
 *
 *  Created on: Dec 20, 2016
 *      Author: user
 */

#ifndef CDACCEPTREPORT_IFACE_V1_H_
#define CDACCEPTREPORT_IFACE_V1_H_

#include "cdtcacceptreport.h"

#endif /* CDACCEPTREPORT_IFACE_V1_H_ */
