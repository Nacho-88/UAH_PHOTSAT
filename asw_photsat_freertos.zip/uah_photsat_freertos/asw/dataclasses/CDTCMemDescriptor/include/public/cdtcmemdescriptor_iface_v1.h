/*
 * cdtcdescriptor_iface_v1.h
 *
 *  Created on: Dec 20, 2016
 *      Author: user
 */

#ifndef CDTCMEMDESCRIPTOR_IFACE_V1_H_
#define CDTCMEMDESCRIPTOR_IFACE_V1_H_

#include "cdtcmemdescriptor.h"

#endif /* CDTCDESCRIPTOR_IFACE_V1_H_ */
